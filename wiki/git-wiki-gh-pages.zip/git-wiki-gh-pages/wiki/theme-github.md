---
layout: "git-wiki-bs-github"
---

# Theme: Github


This is an example of layout built using github css file


To use it as your default theme you've to change layout configuration in your _config.yml, for example:

```
defaults:
 -
    scope:
      path: ""
    values:
      layout: "git-wiki-bs-github"
 -
    scope:
      path: ""
      type: "pages"
    values:
      layout: "git-wiki-bs-github"
```

